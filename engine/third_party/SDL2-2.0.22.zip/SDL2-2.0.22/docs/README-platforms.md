Platforms
=========

We maintain the list of supported platforms on our wiki now, and how to
build and install SDL for those platforms:

    https://wiki.libsdl.org/Installation

